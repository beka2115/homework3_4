package com.example.homework3_4;

public interface OnClick {
void onItemClick(int position);

}
